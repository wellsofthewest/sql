ALTER USER suffolkgis with login=SuffolkGIS;
ALTER USER sde with login=sde;